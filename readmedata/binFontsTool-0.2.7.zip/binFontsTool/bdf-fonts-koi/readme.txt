.bdf fonts, taken from
http://gene.chat.ru/fonts.html
